<form method="post" action="account_login.php">
Username:<br>
<input type="text" name="auth_user" size="25" maxlength="25"></p>
Password:<BR>
<input type="password" name="auth_pw" size="25" maxlength="25"><BR>
<input type="SUBMIT" name="submit" value="Login">
