<?php

// database server:
$DB_SERVER = "localhost";

// username:
$DB_USER = "user1";

// password:
$DB_PASS = "pass1";

// database name:
$DB_NAME = "tracker";

// logout header location: 
$logout_url = "account.php";
?>