<?php 
header('Content-Type: application/vnd.google-earth.kml+xml');
	
echo '<?xml version="1.0" encoding="UTF-8"?>'."\n";

$cnx = mysql_connect('localhost', 'user1', 'pass1');
mysql_select_db('tracker', $cnx);

$cliente = $_GET['cliente'] != "" ? $_GET['cliente'] : "0";

?>

<kml xmlns="http://earth.google.com/kml/2.1">
  <Document>
    <name>Tracker Map</name>
    <description>Tracker</description>

    <Style id="highlightPlacemark">
      <IconStyle>
        <Icon>
          <href>http://<?php echo $_SERVER['SERVER_NAME'] ?>/imagens/local.png</href>
        </Icon>
      </IconStyle>
    </Style>

    <Style id="highlightPlacemarkGreen">
      <IconStyle>
        <Icon>
          <href>http://<?php echo $_SERVER['SERVER_NAME'] ?>/imagens/ultimo_local.png</href>
        </Icon>
      </IconStyle>
    </Style>
	
    <Style id="color1">
      <LineStyle>
        <color>ffff0000</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color2">
      <LineStyle>
        <color>ff0000ff</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color3">
      <LineStyle>
        <color>ff009900</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color4">
      <LineStyle>
        <color>ff00ccff</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color5">
      <LineStyle>
        <color>ffff33ff</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color6">
      <LineStyle>
        <color>ff66a1cc</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color7">
      <LineStyle>
        <color>ffcc00cc</color>
        <width>4</width>
      </LineStyle>
    </Style>
    <Style id="color8">
      <LineStyle>
        <color>ff61f2f2</color>
        <width>4</width>
      </LineStyle>
    </Style>

    <Style id="BalloonStyle">
      <BalloonStyle>
        <!-- a background color for the balloon -->
        <bgColor>ffffffbb</bgColor>
        <!-- styling of the balloon text -->
        <text><![CDATA[
        <b><font color="#CC0000" size="+3">$[name]</font></b>
        <br/><br/>
        <font face="Courier">$[description]</font>
        <br/><br/>
        Extra text that will appear in the description balloon
        <br/><br/>
        <!-- insert the to/from hyperlinks -->
        $[geDirections]
        ]]></text>
      </BalloonStyle>
    </Style>

    <Style id="greenPoint">
      <LineStyle>
        <color>ff009900</color>
        <width>4</width>
      </LineStyle>
    </Style>

<?php

//$step = 255 / $entries;
//echo $step;
$color = 0;

$res2 = mysql_query("select imei, name, identificacao from bem where cliente = $cliente and activated = 'S'");
while($data2 = mysql_fetch_assoc($res2)) 
{

	$imei = $data2['imei'];
	$nome = $data2['name'];
	$identificacao = $data2['identificacao'] != "" ? " - " . $data2['identificacao'] : "";
	
	$color++;
	
	$loop = 0;

	$res = mysql_query("SELECT g.date, g.latitudeDecimalDegrees, g.latitudeHemisphere, g.longitudeDecimalDegrees, g.longitudeHemisphere, g.speed, g.address
						FROM gprmc g WHERE gpsSignalIndicator = 'F' and imei = ". $imei ." ORDER BY id DESC LIMIT 1");
	$line_coordinates = "";
	$ballons = "";

	while($data = mysql_fetch_assoc($res))
	{
		//$trackerdate = ereg_replace("^(..)(..)(..)(..)(..)$","\\3/\\2/\\1 \\4:\\5",$data['date']);
		strlen($data['latitudeDecimalDegrees']) == 9 && $data['latitudeDecimalDegrees'] = '0'.$data['latitudeDecimalDegrees'];
		$g = substr($data['latitudeDecimalDegrees'],0,3);
		$d = substr($data['latitudeDecimalDegrees'],3);
		$latitudeDecimalDegrees = $g + ($d/60);
		$data['latitudeHemisphere'] == "S" && $latitudeDecimalDegrees = $latitudeDecimalDegrees * -1;


		strlen($data['longitudeDecimalDegrees']) == 9 && $data['longitudeDecimalDegrees'] = '0'.$data['longitudeDecimalDegrees'];
		$g = substr($data['longitudeDecimalDegrees'],0,3);
		$d = substr($data['longitudeDecimalDegrees'],3);
		$longitudeDecimalDegrees = $g + ($d/60);
		$data['longitudeHemisphere'] == "S" && $longitudeDecimalDegrees = $longitudeDecimalDegrees * -1;

		$longitudeDecimalDegrees = $longitudeDecimalDegrees * -1;

		$speed = $data['speed'] * 1.609;
		
		$address = utf8_encode($data['address']);
		//Testa se tem endere�o, se nao tiver obtem do google geocode e grava
		if ($address == null or $address == "")
		{
			# Convert the GPS coordinates to a human readable address
			$tempstr = "http://maps.google.com/maps/geo?q=$latitudeDecimalDegrees,$longitudeDecimalDegrees&oe=utf-8&sensor=true&key=$google_maps_key&output=csv"; //output = csv, xml, kml, json
			$rev_geo_str = file_get_contents($tempstr);
			$rev_geo_str = ereg_replace("\"","", $rev_geo_str);
			$rev_geo = explode(',', $rev_geo_str);
			$address = $rev_geo[2] .",". $rev_geo[3] ;
		
			if (!mysql_query("UPDATE gprmc set address = '". utf8_decode($address) ."', date = date where id = $idRota", $cnx))
			{
				//die('Error: ' . mysql_error());
			}
		}
		
		if ($loop == 0) {
			echo '
			<Placemark>
				<name><![CDATA['.$nome.''.$identificacao.']]></name>
				<styleUrl>#highlightPlacemarkGreen</styleUrl>
				<description>
					<![CDATA[
						<font face="Arial" style="font-size:11px">
							End.: '. $address .' <br/>
							Veloc. : '.floor($speed).'Km/h - Data : '.date('d/m/Y H:i:s', strtotime($data['date'])).' <br/>
							Lat: '.$longitudeDecimalDegrees.', Long:'.$latitudeDecimalDegrees. '
						</font>
					]]>
				</description>
				<Point>
				  <coordinates>'."$longitudeDecimalDegrees,$latitudeDecimalDegrees,0".'</coordinates>
				</Point>
			</Placemark>
			
			<Placemark>
				<name>Red Line</name>
				<styleUrl>#color' . $color . '</styleUrl>
				<LineString>
					<altitudeMode>relative</altitudeMode>
					<coordinates>
						'."$longitudeDecimalDegrees,$latitudeDecimalDegrees,0\n";
		} else {
	
			if ($loop != 0) {
				echo "$longitudeDecimalDegrees,$latitudeDecimalDegrees,0\n";
			}
		}
			
		$loop++;
		
	}
	if ($loop > 0)
		echo "			</coordinates>
					</LineString>
				</Placemark>";
}
mysql_close($cnx);
?>
  </Document>
</kml>
