<?php
echo $_SERVER['DOCUMENT_user1'];
?>
